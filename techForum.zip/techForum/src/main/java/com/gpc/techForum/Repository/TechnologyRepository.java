package com.gpc.techForum.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.gpc.techForum.Entity.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology, Integer> {}
