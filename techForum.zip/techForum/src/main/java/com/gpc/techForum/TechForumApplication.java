package com.gpc.techForum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechForumApplication{

	public static void main(String[] args) {
		SpringApplication.run(TechForumApplication.class, args);
	}

}
