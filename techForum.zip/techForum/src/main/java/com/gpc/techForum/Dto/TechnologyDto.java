package com.gpc.techForum.Dto;

public class TechnologyDto {

	private int TechId;
	
	private String Name;

	public int getTechId() {
		return TechId;
	}

	public void setTechId(int techId) {
		TechId = techId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
}
