package com.gpc.techForum.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import com.gpc.techForum.Entity.JoinEmployeeTechnology;
import com.gpc.techForum.Repository.JoinEmployeeTechnologyRepository;

public class JoinEmployeeTechnologyService {

@Autowired JoinEmployeeTechnologyRepository repository;
	
	public void add(JoinEmployeeTechnology joinEmployeeTechnology) {
        repository.save(joinEmployeeTechnology);
    }
    public void delete(long id) {
        repository.deleteById(id);
    }
    public List<JoinEmployeeTechnology> getAll() {
        return (List<JoinEmployeeTechnology>) repository.findAll();
    }
    public JoinEmployeeTechnology getById(long id) {
        Optional<JoinEmployeeTechnology> optionalJoinEmployeeTechnology = repository.findById(id);
        if(optionalJoinEmployeeTechnology.isPresent())
        {
        	return optionalJoinEmployeeTechnology.get();
        }
        return null;
    }
}
