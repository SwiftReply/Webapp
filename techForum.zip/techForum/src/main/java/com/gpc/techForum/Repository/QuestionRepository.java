package com.gpc.techForum.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.gpc.techForum.Entity.Question;

@Repository
public interface QuestionRepository extends CrudRepository<Question, Long> {}
