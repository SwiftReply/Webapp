package com.gpc.techForum.Dto;

public class JoinEmployeeTechnologyDto {

	private String Empid;
	
	private int TechId;
	
    private long Id;

	public String getEmpid() {
		return Empid;
	}

	public void setEmpid(String empid) {
		Empid = empid;
	}

	public int getTechId() {
		return TechId;
	}

	public void setTechId(int techId) {
		TechId = techId;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}
}
